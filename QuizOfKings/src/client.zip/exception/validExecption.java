package exception;

public class validExecption extends RuntimeException {
    public validExecption(String message) {
        super(message);
    }
}
