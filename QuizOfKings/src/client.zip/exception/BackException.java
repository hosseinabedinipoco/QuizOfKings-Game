package exception;

public class BackException extends RuntimeException {
    public BackException() {
        super();
    }
}
