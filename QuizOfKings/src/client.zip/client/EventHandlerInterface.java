package client;

import java.io.IOException;

public interface EventHandlerInterface {
    void run() throws IOException, ClassNotFoundException;
}
